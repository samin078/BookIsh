//
//  BookFetcherView.swift
//  BookIsh2.0
//
//  Created by Rakibul Nasib on 14/11/23.
//

import SwiftUI

struct BookFetcherView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    BookFetcherView()
}
